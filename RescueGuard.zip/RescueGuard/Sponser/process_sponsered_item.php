              <?php 
              session_start();
        //Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

 $logid=$_SESSION["slogid"];    
if (isset($_POST['submit'])) 
{
  
$required_id=$_POST["required_id"];

$qty=$_POST["qty"];


  $sql="insert into tbl_sponsered_item(required_id,sponser_login_id,quantity) values('$required_id','$logid','$qty')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Sponsered Item is added Successfully");
             window.location="required_item.php";

              </script>
            <?php 
        }
       
       

}
          ?> 