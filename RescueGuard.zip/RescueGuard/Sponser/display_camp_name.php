
									<option value="">--Select--</option>
									<?php
									$place=$_GET["place"];
									
include('../dbconnection.php');
$db=new dbconnection;
$res= $db->execute_query("select * from tbl_camp where place_id=$place");
while($row=mysqli_fetch_array($res))
{
	?>
	<option value="<?php echo $row["login_id"]?>"><?php echo $row["camp_name"]?></option>

	<?php
}


									?>