<?php
$fname=$_POST["fname"];
$lname=$_POST["lname"];

$place_id=$_POST["city"];
$hname=$_POST["hname"];
$gender=$_POST["gender"];
$dob=$_POST["dob"];
$phno=$_POST["phone_no"];
$rphno=$_POST["rphone_no"];

$emailid=$_POST["emailid"];

$username=$_POST["username"];
$password=md5($_POST["password"]);
//Include dboperation class file 
 include_once("dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

$sql="select * from tbl_login where username='$username'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c==0)
  {  
 $sql="insert into tbl_login(username,password,usertype,status) values('$username','$password','User','Approved')";
       $res2=$db->execute_query($sql); 
       $login_id = mysqli_insert_id($db->con); 
    
     
       $sql2="insert into tbl_user_registration( firstname, lastname, place_id, house_name, gender, date_of_birth, phone_number, relative_phone_number, email_id,login_id) values('$fname','$lname',$place_id,'$hname','$gender','$dob','$phno','$rphno','$emailid','$login_id')";
        $res1=$db->execute_query($sql2);
 
            if($res1)
            {
              ?>
              <script type="">
                alert("User is added Successfully");
              window.location="user_registration.php";

              </script>
            <?php 
        }
        }
        else
        {
          ?>
              <script type="">
                alert("Username Already Exist.. Try again");
              window.location="user_registration.php";

              </script> 
     <?php    }

?>




