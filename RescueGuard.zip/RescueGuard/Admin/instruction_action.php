<?php
$disaster_type=$_POST["disaster_type"];
$instruction=$_POST["instruction"];

//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();


 $sql="insert into tbl_instruction(disaster_type_id,instruction) values('$disaster_type','$instruction')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Instruction is added Successfully");
              window.location="add_instrctions.php";

              </script>
            <?php 
        }
       

?>




