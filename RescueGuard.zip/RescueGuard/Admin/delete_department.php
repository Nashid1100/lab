<?php
$department_id=$_GET["department_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_department_camp where department_id=$department_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Department is deleted Successfully");
              window.location="camp_department.php";

              </script>
            <?php 
        }
?>