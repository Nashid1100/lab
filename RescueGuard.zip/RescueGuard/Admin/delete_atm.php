<?php
$atm_id=$_GET["atm_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_atm where atm_id=$atm_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("ATM is deleted Successfully");
              window.location="atm.php";

              </script>
            <?php 
        }
?>