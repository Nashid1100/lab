<?php
include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$disaster_type=$_POST['disaster_type'];

?>
<?php
  $s="select * from tbl_disaster_type where disaster_type='$disaster_type'";

$res=$db->execute_query($s);
$n=mysqli_num_rows($res);

 if($n>0)
 {
 	echo json_encode(array("statusCode"=>200,"message"=>'Already Exist!!!!!!!!!!!'));
}
else {
  

$res=$db->execute_query("insert into tbl_disaster_type(disaster_type)values('$disaster_type')");

$htmlData="";
if ($res) {
$htmlData = $htmlData.'<table class="table">
	
	
	<thead>
							<tr><th>#</th><th>Type</th><th>Delete</th></tr></thead><tbody>
							
							';
			
$count=1;
  $cls="odd";
 $sql="select * from tbl_disaster_type";
       $res2=$db->execute_query($sql); 
       while ($row=mysqli_fetch_array($res2)) {
       
     $htmlData =  $htmlData.'<tr><td>'.$count.'</td><td>'.$row["disaster_type"].'</td><td><input type="button" class="trash btn btn-danger"  id="'.$row["disaster_type_id"].'"value="Delete"></td></tr>';

       	$count++;
     }

     $htmlData =  $htmlData.'</tbody></table>';
	
		echo json_encode(array("statusCode"=>200,"result"=>$htmlData,"message"=>'Added Successfully'));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}

}   
?>