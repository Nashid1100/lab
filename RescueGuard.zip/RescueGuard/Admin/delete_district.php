<?php
$district_id=$_GET["district_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_district where district_id=$district_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("District is deleted Successfully");
              window.location="district.php";

              </script>
            <?php 
        }
?>