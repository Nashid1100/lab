<?php
$bank=$_POST["bank"];

//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

$sql="select * from tbl_bank where bank ='$bank'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c==0)
  {  
  $sql="insert into tbl_bank(bank) values('$bank')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Bank is added Successfully");
              window.location="bank.php";

              </script>
            <?php 
        }
        }
        else
        {
          ?>
              <script type="">
                alert("Bank Already Exist.. Try again");
              window.location="bank.php";

              </script> 
     <?php    }

?>




