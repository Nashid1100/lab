<?php
$hospital_id=$_GET["hospital_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_hospital where hospital_id=$hospital_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Hospital is deleted Successfully");
              window.location="hospital.php";

              </script>
            <?php 
        }
?>