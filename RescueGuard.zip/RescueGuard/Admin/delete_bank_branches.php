<?php
$bank_branches_id=$_GET["bank_branches_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_bank_branches where bank_branches_id=$bank_branches_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Bank Branches is deleted Successfully");
              window.location="bank_branches.php";

              </script>
            <?php 
        }
?>