<?php $state=$_GET["state1"]; 
include('../dbconnection.php');
$db=new dbconnection;

?>
<h3 style="width:70%;margin: auto;">District List</h3>
              <?php

$res= $db->execute_query("select * from tbl_state inner join tbl_district on tbl_state.state_id=tbl_district.state_id where tbl_district.state_id='$state' order by district_name");
$n=mysqli_num_rows($res);
if($n>0)
{
?>
 <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>State</th>
                   <th>District</th>
                   <th>Delete</th>
                  
                    
                     
                      


                </tr>
              </thead>
              <tbody>
<?php
$count=1;
while($row=mysqli_fetch_array($res))
{
    ?>

    <tr><td><?php echo $count; ?></td><td><?php echo $row["state_name"] ?></td>
    	<td><?php echo $row["district_name"] ?></td>

<td><a class="btn btn-danger" href="delete_district.php?district_id=<?php echo $row["district_id"] ?>">Delete</a></td>

    </tr>
    

    <?php
    $count++;
}
}
else
{
  
  ?>
  <div style="padding: 20px; margin:50px; background-color: red; color: #fff">No List Available</div>
  <?php
}
?></tbody>
</table>