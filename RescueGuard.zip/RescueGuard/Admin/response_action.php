<?php
$response=$_POST["response"];
$complaint_id=$_POST["complaint_id"];


//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
 
   $sql="update tbl_complaints set response='$response' where complaint_id='$complaint_id'";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Response is added Successfully");
              window.location="complaint.php";

              </script>
            <?php 
        }
       ?>




