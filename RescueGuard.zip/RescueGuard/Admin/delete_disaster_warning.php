<?php
$id=$_GET["id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from  tbl_disaster_warning where disaster_warning_id='$id'";
       $res1=$db->execute_query($sql);
        $sql2="delete from  tbl_evacuation_points where disaster_warning_id='$id'";
       $res22=$db->execute_query($sql2);
       
?>