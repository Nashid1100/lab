<?php
include_once("sms.php");
$camp=$_POST["camp"];


$place_id=$_POST["city"];
$capacity=$_POST["capacity"];
$phone_number=$_POST["phone_number"];

$username=$_POST["username"];

$reason=$_POST["reason"];
$pswd=$_POST["password"];
$password=md5($pswd);
$longitude=$_POST["longitude"];
$latitude=$_POST["latitude"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

$sql="select * from tbl_login where username='$username'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c==0)
  {  
 $sql="insert into tbl_login(username,password,usertype,status) values('$username','$password','Camp','Approved')";
       $res2=$db->execute_query($sql); 
       $login_id = mysqli_insert_id($db->con); 
    
     
        $sql2="insert into tbl_camp(camp_name, place_id, login_id, longitude, latitude, capacity,phone_number) values('$camp','$place_id',$login_id,'$longitude','$latitude','$capacity','$phone_number')";
      
        $res1=$db->execute_query($sql2);
     
          $d=date("Y-m-d");
         $sql22="insert into tbl_camp_status(starting_date,camp_login_id,reason_for_camp )values('$d','$login_id','$reason')";
        $res12=$db->execute_query($sql22);
        $obj=new sms;
  $msg1="$camp has been selected as Camp. People Capacity is $capacity. $reason";
$obj->sendsms($phone_number,$msg1);
 $msg2="User name : $username. Password : $pswd";
$obj->sendsms($phone_number,$msg2);
            if($res1)
            {
              ?>
              <script type="">
                alert("Camp is added Successfully");
              window.location="add_camp.php";

              </script>
            <?php 
        }
        }
        else
        {
          ?>
              <script type="">
                alert("Username Already Exist.. Try again");
              window.location="add_camp.php";

              </script> 
     <?php    }

?>




