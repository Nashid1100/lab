<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Rescue Guard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->
 
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts--> 

<!-- chart -->
<script src="js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}
</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
    <script type="text/javascript">
    	
    </script>
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="css/owl.carousel.css" rel="stylesheet">
					<script src="js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>
					<!-- //requried-jsfiles-for owl -->
					<script type="text/javascript" src="validation.js"></script>
</head> 

<body class="cbp-spmenu-push">
	<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <h1><a class="navbar-brand" href="login.php"><span><img src="images/r.png" style="width:80%"></a></h1>
            
          </div>
           <br>
            <br>
            <br>
            <br>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header"></li>
              <li class="treeview">
                <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Home</span>
                </a>
              </li>
               <li class="treeview">
                <a href="about_us.php">
                <i class="fa fa-arrow-circle-right"></i> <span>About Us</span>
                </a>
              </li>
			 <li class="treeview">
                <a href="login.php">
                <i class="fa fa-sign-in"></i> <span>Login</span>
                </a>
              </li>
               <li class="treeview">
                <a href="user_registration.php">
                <i class="fa fa-user"></i> <span>User Registration</span>
                </a>
              </li>
               <li class="treeview">
                <a href="sponser_registration.php">
                <i class="fa fa-user"></i> <span>Sponser Registration</span>
                </a>
              </li>
               <li class="treeview">
                <a href="instructions.php">
                <i class="fa fa-user"></i> <span>Instructions</span>
                </a>
            </li>
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>
		<!--left-fixed -navigation-->
		
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				
				<!--toggle button end-->
				<div class="profile_details_left"><!--notifications of menu start -->
		
					<div class="clearfix"> </div>
				</div>
				<!--notification menu end -->
				<div class="clearfix"> </div>
			</div>
			<div class="header-right">
				
				
				<!--search-box-->
			
				
				<div class="profile_details">		
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<div class="profile_img">	
									<span class="prfil-img"><img src="images/p3.jpg" alt=""> </span> 
									<div class="user-name">
										<p>Guest User</p>
										<span>Guest</span>
									</div>
									<i class="fa fa-angle-down lnr"></i>
									<i class="fa fa-angle-up lnr"></i>
									<div class="clearfix"></div>	
								</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
								<li> <a href="index.php"><i class="fa fa-cog"></i> Home</a> </li> 
								<li> <a href="about_us.php"><i class="fa-arrow-circle-right"></i> About Us</a> </li> 
								<li> <a href="login.php"><i class="fa fa-sign-in"></i> Login</a> </li> 
								<li> <a href="user_registration.php"><i class="fa fa-user"></i> User Registration</a> </li>
								 <li >
                <a href="sponser_registration.php">
                <i class="fa fa-user"></i> <span>Sponser Registration</span>
                </a>
              </li>
							</ul>
						</li>
					</ul>
				</div>
				<div class="clearfix"> </div>				
			</div>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
	


	<div id="page-wrapper">
			<div class="main-page login-page ">
				<h2 class="title1">Login</h2>
				<div class="widget-shadow">
          <center>
            <img src="images/hi.png" alt="Avatar" style="width:35%" class="w3-square w3-margin-top">
            </center>
					<div class="login-body">
						<form action="process_action.php" method="post" name="f1" id="myForm">
							Username
							<input type="text" class="form-control" id="username" name="username" placeholder="Enter Your username" >
							<div id="error_username" class="alert alert-warning" style="display:none"></div>
							Password
							
							<input type="password" name="password" id="password" class="form-control" placeholder="Password">
							<div id="error_password" class="alert alert-warning" style="display:none"></div>
							<input type="submit" name="Sign In" value="Sign In" >
							<div class="registration">
								Don't have an account ?
								<a class="" href="user_registration.php">
									Create an account
								</a>
							</div>
              <div class="registration">
              Forget Your Password ?
                <a class="" href="forget_password.php">
                 Forget Password
                </a>
              </div>
						</form>
						 <style type="text/css">
    #myForm label.error {
    color: #FB3A3A;
    display: inline-block;
    margin: 0px 0 0px 0px;
    padding: 0;
    text-align: left;
    }
</style>
            

    <!-- jQuery Form Validation library -->
    <script src="jquery/jquery.js"></script>
<script src="jquery/jquery-ui.js"></script>
    <script src="js/jquery_validate.js"></script>
             
  <script type="text/javascript">
  (function ($, W, D)
  {
  var JQUERY4U = {};
  JQUERY4U.UTIL =
      {
          setupFormValidation: function ()
          {
            $.validator.addMethod(
    "regex",
    function(value, element, regexp) {
        var check = false;
        return this.optional(element) || regexp.test(value);
    },
    "Not a valid Input."
);
   
          //form validation rules
          $("#myForm").validate({
              rules: {
             
                   username: {
                      required: true,
                     regex : /^[A-Za-z0-9]+$/,
                       minlength: 5,
                       maxlength: 15,
                     
                  },
 password: {
                      required: true,
                     regex : /^[A-Za-z0-9]+$/,
                       minlength: 5,
                       maxlength: 15,
                     
                  },
            
                  
              },
              messages: {
              
                username: "Please Enter Valid User Name(5-15 digit alphanumeric username",
                    password: "Please Enter Valid User Name(5-15 digit alphanumeric password",
                     
              },
              submitHandler: function (form) {
              form.submit();
              }
          });
        }
      }
  //when the dom has loaded setup form validation rules
  $(D).ready(function ($) {
      JQUERY4U.UTIL.setupFormValidation();
  });
  })(jQuery, window, document);
</script>
					</div>
				</div>
				
			</div>
		</div>
		
		<div class="col_1">
			<div class="col-md-4 span_8">
				
					
			</div>
			<div class="col-md-4 span_8">
				
			</div>
			<div class="col-md-4 span_8">
				
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
			
		</div>
				
			</div>
		</div>
	<!--footer-->
	<div class="footer">
	   <p>&copy;  All Rights Reserved | Design by <a href="index.php" target="_blank">Rescue Guard</a></p>		
	</div>
    <!--//footer-->
	</div>
		
	<!-- new added graphs chart js-->
	
    
	<!-- //for index page weekly sales java script -->
	
	
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
	<!-- //Bootstrap Core JavaScript -->
	
</body>
</html>