/*$(document).ready(function() {
 $('#username').on('blur', function() {
  var alpfnumeric = /^[A-Za-z0-9]+$/;  
    var username = $('#username').val();
 if(username=="" || (!username.match(alpfnumeric)) || (username.length < 5) || (username.length
   > 15) || !isNaN(username))
{
 $("#error_username").show();
 $('#error_username').html("Alphanumer User Name with 5 to 15 letters" ); 
}
else
{
  $("#error_username").hide();   
}

 });


 $('#password').on('blur', function() {
  var alpfnumeric = /^[A-Za-z0-9]+$/;  
    var password = $('#password').val();
 if(password=="" || (!password.match(alpfnumeric)) || (password.length < 5) || (password.length
   > 15) || !isNaN(password))
{
 $("#error_password").show();
 $('#error_password').html("Alphanumeric password with 5 to 15 letters" ); 
}
else
{
  $("#error_password").hide();   
}

 });
$('#fname').on('blur', function() {
var letters = /^[A-Za-z]+$/; 
    var fname = $('#fname').val();
 if(fname=="" || (!fname.match(letters)))
{
 $("#error_fname").show();
 $('#error_fname').html("Firstname field Must contain only alphabets" ); 
}
else
{
  $("#error_fname").hide();   
}

 });
$('#lname').on('blur', function() {
var letters = /^[A-Za-z]+$/; 
    var lname = $('#lname').val();
 if(lname=="" || (!lname.match(letters)))
{
 $("#error_lname").show();
 $('#error_lname').html("Last name field Must contain only alphabets" ); 
}
else
{
  $("#error_lname").hide();   
}

 });


$('#hname').on('blur', function() {
var letters = /^[A-Za-z ]+$/; 
    var hname = $('#hname').val();
 if(hname=="" || (!hname.match(letters)))
{
 $("#error_hname").show();
 $('#error_hname').html("Valid House Name" ); 
}
else
{
  $("#error_hname").hide();   
}
    var state = $('#state').val();
if(state==0)
{
 $("#error_state").show();
 $('#error_state').html("Choose State" ); 
}

 var district = $('#district').val();
if(district==0)
{
 $("#error_district").show();
 $('#error_district').html("Choose district" ); 
}

 var city = $('#city').val();
if(city==0)
{
 $("#error_city").show();
 $('#error_city').html("Choose city" ); 
}
 });

$('#state').on('change', function() {

    var state = $('#state').val();
 if(state==0)
{
 $("#error_state").show();
 $('#error_state').html("Choose State" );
}
else
{
  $("#error_state").hide();   
}

 });
$('#state').on('change', function() {

    var district = $('#district').val();
 if(district==0)
{
 $("#error_district").show();
 $('#error_district').html("Choose district " );
}
else
{
  $("#error_district").hide();   
}
  var city = $('#city').val();
 if(city==0)
{
 $("#error_city").show();
 $('#error_city').html("Choose city" );
}
else
{
  $("#error_city").hide();   
}
 });

$('#district').on('change', function() {

    var district = $('#district').val();
 if(district==0)
{
 $("#error_district").show();
 $('#error_district').html("Choose district " );
}
else
{
  $("#error_district").hide();   
}
  var city = $('#city').val();
 if(city==0)
{
 $("#error_city").show();
 $('#error_city').html("Choose city" );
}
else
{
  $("#error_city").hide();   
}
 });


$('#city').on('change', function() {

   

  var city = $('#city').val();
 if(city==0)
{
 $("#error_city").show();
 $('#error_city').html("Choose city" );
}
else
{
  $("#error_city").hide();   
}
 });
$('#phone_no').on('blur', function() {
var letters = /^[A-Za-z ]+$/; 
    var dob = $('#dob').val();
 if(dob=="")
{
 $("#error_dob").show();
 $('#error_dob').html("Choose Your Date Of birth" ); 
}
else
{
  $("#error_dob").hide();   
} 

if(document.f1.gender[0].checked==false && document.f1.gender[1].checked==false)
 {
$("#error_gender").show();
 $('#error_gender').html("Choose Gender" ); 
 }
 else
 {
  $("#error_gender").hide(); 
 }

 var phone_no = $('#phone_no').val();
 if(phone_no=="")
{
 $("#error_phone").show();
 $('#error_phone').html("Phone Number" ); 
}
else
{
  $("#error_phone").hide();   
} 
});



  });
*/
function validate_login()
{
	var username=document.getElementById("username").value;
        var alpfnumeric = /^[A-Za-z0-9]+$/;                    
      if(username=="" || (!username.match(alpfnumeric)) || (username.length < 5) || (username.length
   > 15) || !isNaN(username))
{

                 alert("Please Enter Valid Username");
                  document.f1.username.focus();
                    return false;
            } 
            var password=document.getElementById("password").value;
                          
       if(password=="" || (!password.match(alpfnumeric)) || (password.length < 5) || (password.length
   > 15) || !isNaN(password)){

                 alert("Please Enter Valid password");
                  document.f1.password.focus();
                    return false;
            }
           }

  function validate_user_registration()
  {
  	var letters = /^[A-Za-z]+$/;
	var fname=document.getElementById("fname").value;
                          
       if(fname==""  ||   (!fname.match(letters)) )
       {


               alert("Please Enter Valid First Name");
                 document.f1.fname.focus();
                                return false;
            }


 
     var lname=document.getElementById("lname").value;
                            
          if(lname=="" ||  (!lname.match(letters)) ){
             alert("Please Enter Valid Last Name");
               document.f1.lname.focus();
                                return false;
                            } 

var state=document.getElementById("state").value;
                          
       if(state==0)
       {


                 alert("Please choose state");
                 
                    return false;
            }
            var district=document.getElementById("district").value;
                          
       if(district==0)
       {


                 alert("Please choose district");
                 
                    return false;
            } 
        var city=document.getElementById("city").value;
                          
       if(city==0)
       {


                 alert("Please choose city");
                 
                    return false;
            }  
var hname=document.getElementById("hname").value;
                            
          if(hname=="" ||  !isNaN(hname) ){
             alert("Please Enter Valid House Name");
               document.f1.hname.focus();
                                return false;
 } 
 if(document.f1.gender[0].checked==false && document.f1.gender[1].checked==false)
 {
alert("Please choose your gender");
return false;
 }
var dob=document.getElementById("dob").value;
                            
          if(dob=="" ){
             alert("Please Enter Valid Date of Birth");
               document.f1.dob.focus();
                                return false;
 } 

      var phone_npt = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;

var phone_no=document.getElementById("phone_no").value;
  if(!phone_no.match(phone_npt))
        {
         
  alert("Please Enter Valid 10 digit Phone Number - Starting from 7 or 8 or 9");
       document.f1.phone_no.focus();
return false;
          }

var rphone_no=document.getElementById("rphone_no").value;
  if(!rphone_no.match(phone_npt))
        {
         
  alert("Please Enter Valid 10 digit Realtive Phone Number - Starting from 7 or 8 or 9");
       document.f1.rphone_no.focus();
return false;
          }
        


   var emailid=document.getElementById("emailid").value;
     var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(!emailid.match(mailformat))
{
  alert("Please Enter Valid Email Id");
       document.f1.emailid.focus();
return false;
} 
 var alpfnumeric = /^[A-Za-z0-9]+$/;   
var username=document.getElementById("username").value;
  if(username=="" || (!username.match(alpfnumeric)) || (username.length < 5) || (username.length
   > 15) || !isNaN(username)){
    alert("Please Enter Valid User Name(5-15 digit alphanumeric username)");
                     document.f1.username.focus();
                                return false;
                            }
                            
    var password=document.getElementById("password").value;
                            
if(password=="" || (!password.match(alpfnumeric)) || (password.length < 5) || (password.length > 15) || !isNaN(password)){
                                alert("Please Enter your Password(5-15 digit alphanumeric Password)");
                                document.f1.password.focus();
                                return false;
                            }
                           
                            
                            var cpassword=document.getElementById("cpassword").value;
                            
                            if(cpassword==""){
                                alert("Please Enter your Confirm Password");
                                document.f1.cpassword.focus();
                                return false;
                            }
                           
                            
                             else{
                                if(password!=cpassword){
                                    alert("Password doesn't match")
                                    document.f1.cpassword.focus();
                                    return false;
                                }
                            }
                           
  }
 function validate_sponser_registration()
 {
   	var letters = /^[A-Za-z]+$/;
	var fname=document.getElementById("fname").value;
                          
       if(fname==""  ||   (!fname.match(letters)) )
       {


               alert("Please Enter Valid First Name");
                 document.f1.fname.focus();
                                return false;
            }


 
     var lname=document.getElementById("lname").value;
                            
          if(lname=="" ||  (!lname.match(letters)) ){
             alert("Please Enter Valid Last Name");
               document.f1.lname.focus();
                                return false;
                            } 

var state=document.getElementById("state").value;
                          
       if(state==0)
       {


                 alert("Please choose state");
                 
                    return false;
            }
            var district=document.getElementById("district").value;
                          
       if(district==0)
       {


                 alert("Please choose district");
                 
                    return false;
            } 
        var city=document.getElementById("city").value;
                          
       if(city==0)
       {


                 alert("Please choose city");
                 
                    return false;
            }  
var hname=document.getElementById("hname").value;
                            
          if(hname=="" ||  !isNaN(hname) ){
             alert("Please Enter Valid House Name");
               document.f1.hname.focus();
                                return false;
 } 
 if(document.f1.gender[0].checked==false && document.f1.gender[1].checked==false)
 {
alert("Please choose your gender");
return false;
 }
var dob=document.getElementById("dob").value;
                            
          if(dob=="" ){
             alert("Please Enter Valid Date of Birth");
               document.f1.dob.focus();
                                return false;
 } 

      var phone_npt = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;

var phone_no=document.getElementById("phone_no").value;
  if(!phone_no.match(phone_npt))
        {
         
  alert("Please Enter Valid 10 digit Phone Number - Starting from 7 or 8 or 9");
       document.f1.phone_no.focus();
return false;
          }

        


   var emailid=document.getElementById("emailid").value;
     var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(!emailid.match(mailformat))
{
  alert("Please Enter Valid Email Id");
       document.f1.emailid.focus();
return false;
} 
 var alpfnumeric = /^[A-Za-z0-9]+$/;   
var username=document.getElementById("username").value;
  if(username=="" || (!username.match(alpfnumeric)) || (username.length < 5) || (username.length
   > 15) || !isNaN(username)){
    alert("Please Enter Valid User Name(5-15 digit alphanumeric username)");
                     document.f1.username.focus();
                                return false;
                            }
                            
    var password=document.getElementById("password").value;
                            
if(password=="" || (!password.match(alpfnumeric)) || (password.length < 5) || (password.length > 15) || !isNaN(password)){
                                alert("Please Enter your Password(5-15 digit alphanumeric Password)");
                                document.f1.password.focus();
                                return false;
                            }
                           
                            
                            var cpassword=document.getElementById("cpassword").value;
                            
                            if(cpassword==""){
                                alert("Please Enter your Confirm Password");
                                document.f1.cpassword.focus();
                                return false;
                            }
                           
                            
                             else{
                                if(password!=cpassword){
                                    alert("Password doesn't match")
                                    document.f1.cpassword.focus();
                                    return false;
                                }
                            }	
 }