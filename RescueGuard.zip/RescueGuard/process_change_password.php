<?php

$username=$_POST["username"];

$npassword=md5($_POST["npassword"]);
include_once("dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
     
          $sql="select * from tbl_login where username='$username'";
$res=$db->execute_query($sql);
        $c=mysqli_num_rows($res);
        if($c>0)
        {
              $sql1="update tbl_login set password='$npassword'  where username='$username'";
$res1=$db->execute_query($sql1);
if($res1)
        {
            ?>
                <script type="">
                    alert("Password Changed Successfully");
                    window.location="login.php";

                </script>
            <?php 
        }

        }
        else
        {
         ?>
                <script type="">
                    alert("Submitted details are wrong...Try Again");
                    window.location="login.php";

                </script>
            <?php    
        }
 ?>