<?php
session_start();
$oname=$_POST["oname"];
$city=$_POST["city"];
$ration_card_number=$_POST["ration_card_number"];
$aadhar_no=$_POST["aadhar_no"];
$phone_no=$_POST["phone_no"];
$description=$_POST["description"];
$bank=$_POST["bank"];
$ifsc=$_POST["ifsc"];
$address=$_POST["address"];
$acno=$_POST["acno"];
$logid=$_SESSION["slogid"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();


 $sql="insert into  tbl_lost_items( owner_name, place_id, ration_card_number, aadhaar_no, phone_number, description, bank_id, account_number, ifsc_code, camp_login_id,address ) values('$oname','$city','$ration_card_number','$aadhar_no','$phone_no','$description','$bank','$acno','$ifsc','$logid','$address')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Lost item details  is added Successfully");
              window.location="add_lost_item.php";

              </script>
            <?php 
        }
       
?>




