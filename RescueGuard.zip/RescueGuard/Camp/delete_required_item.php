<?php
$required_id=$_GET["required_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from  tbl_camp_requirements where required_id=$required_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Required Item is deleted Successfully");
              window.location="requirements_list.php";

              </script>
            <?php 
        }
?>