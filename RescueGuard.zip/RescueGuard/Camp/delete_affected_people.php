<?php
$affected_people_id=$_GET["affected_people_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from  tbl_affected_people where affected_people_id=$affected_people_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Deleted Successfully");
              window.location="view_affected_people.php";

              </script>
            <?php 
        }
?>