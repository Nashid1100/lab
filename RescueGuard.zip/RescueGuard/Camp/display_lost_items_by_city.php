 <?php session_start(); ?>
 <h4 class="title">Lost Item List  In Camp</h4>
           <?php
                    include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$count=1;
  $cls="odd";
  $place_id=$_GET["place"];
  $logid=$_SESSION["slogid"];
   $sql="select * from  tbl_lost_items inner join tbl_bank on tbl_lost_items.bank_id=tbl_bank.bank_id inner join tbl_place on tbl_lost_items.place_id = tbl_place.place_id inner join tbl_district on tbl_district.district_id=tbl_place.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id  where tbl_lost_items.camp_login_id='$logid' and tbl_lost_items.place_id='$place_id' order by tbl_lost_items.entry_date desc";
       $res2=$db->execute_query($sql); 
       if(mysqli_num_rows($res2))
       {
        ?>
         <table class="table table-bordered">
    
    
    <thead>
                            <tr class="alert alert-info"><th>#</th>
                              <th>Owner Name</th>
<th>Details</th>
<th>Ration Card Number</th>
<th>Adhaar Number</th>
<th>Phone Number</th>
<th>Address</th>
<th>Description</th>
<th>Bank Details</th>
                              <th>Applied Date</th></tr></thead><tbody>
        <?php
       while ($row=mysqli_fetch_array($res2)) {

        ?>
        <tr><td><?php echo $count; ?></td>
          <td><?php echo $row["owner_name"] ?></td> 
          <td>
 <div><b>Place:</b> <?php echo $row["place_name"] ?></div>
  <div><b>District:</b> <?php echo $row["district_name"] ?></div>
   <div><b>State:</b> <?php echo $row["state_name"] ?></div>
          </td>
         
           <td><?php echo $row["ration_card_number"] ?></td> 
              <td><?php echo $row["aadhaar_no"] ?></td> 
             <td><?php echo $row["phone_number"] ?></td>  
               <td><?php echo $row["address"] ?></td> 
             <td><?php echo $row["description"] ?></td> 
            
             <td>
 <div><b>Bank Name:</b> <?php echo $row["bank"] ?></div>
  <div><b>Account Number:</b> <?php echo $row["account_number"] ?></div>
   <div><b>IFSC Code:</b> <?php echo $row["ifsc_code"] ?></div>
          </td>
          
               <td><?php echo $row["entry_date"] ?></td>    
         <script type="text/javascript">
function DoFunc()
{
    if (confirm('Are you sure?'))
    {
        
        return true;
    }
    return false;
}
</script>
 <td><a onclick="return DoFunc()" href="lost_item_details_edit.php?lost_items_id=<?php echo $row["lost_items_id"]; ?>" class="btn btn-success">Edit</a></td>
 <td><a onclick="return DoFunc()" href="lost_item_details_delete.php?lost_items_id=<?php echo $row["lost_items_id"]; ?>" class="btn btn-danger">Delete</a></td>
</tr>
        <?php
        $count++;
       }
                            ?></tbody>
                        </table>
<?php }

else
{
  ?>
  <div class="alert alert-info">No Records Found</div>
  <?php
} ?>  