  <?php 
     session_start();      
if (isset($_POST['submit'])) 
{
   //Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

 $logid=$_SESSION["slogid"];
$item=$_POST["item"];


  $sql="select * from tbl_required_item where   item='$item' and camp_login_id='$logid'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c==0)
  {  
  $sql="insert into tbl_required_item(item,camp_login_id) values('$item','$logid')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
             //   alert("Item is added Successfully");
            //  window.location="required_item.php";

              </script>
            <?php 
        }
        }
        else
        {
          ?>
              <script type="">
                //alert("Item Already Exist.. Try again");
             // window.location="required_item.php";

              </script> 
     <?php    }


}
          ?>   