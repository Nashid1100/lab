<?php
session_start();
$staff=$_POST["staff"];
$city=$_POST["city"];
$department=$_POST["department"];
$gender=$_POST["gender"];
$phone_no=$_POST["phone_no"];
$logid=$_SESSION["slogid"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();


 $sql="insert into  tbl_camp_staff( staff_name ,  gender ,  department_id ,  place_id ,  staff_phone_no,camp_login_id ) values('$staff','$gender','$department','$city','$phone_no','$logid')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Staff record  is added Successfully");
              window.location="add_staff.php";

              </script>
            <?php 
        }
       
?>




