<?php
include('../dbconnection.php');
$db=new dbconnection;   

              function distance($lat1, $lon1, $lat2, $lon2, $unit) {
  if (($lat1 == $lat2) && ($lon1 == $lon2)) {
    return 0;
  }
  else {
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);

    if ($unit == "K") {
      return ($miles * 1.609344);
    } else if ($unit == "N") {
      return ($miles * 0.8684);
    } else {
      return $miles;
    }
  }
}            
        $d=date('y-m-d');
         $place_id=$_GET["place"];                        
         $sql="select * from tbl_bank_branches inner join tbl_bank on tbl_bank_branches.bank_id=tbl_bank.bank_id inner join tbl_place on tbl_bank_branches.place_id = tbl_place.place_id inner join tbl_district on tbl_district.district_id=tbl_place.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id where tbl_bank_branches.place_id='$place_id'";
$res= $db->execute_query($sql);
$n=mysqli_num_rows($res);
if($n>0)
{
?>
 <table class="table  table-bordered">
              <thead>
                <tr class="alert alert-info">
                  <th>No.</th>
                  <th>Bank Name</th>
                   <th>Place Details</th>
                    <th>Proper Place</th>
                      
                    
                     
                      


                </tr>
              </thead>
              <tbody>
<?php
$count=1;
while($row=mysqli_fetch_array($res))
{
    $longitude = $row["longitude"];
  $latitude = $row["latitude"];

  $sql2="select * from   tbl_disaster_warning where date(date_time)>='$d'";
       $res22=$db->execute_query($sql2); 
      
  while ($row2=mysqli_fetch_array($res22)) {
     $wlongitude=$row2["longitude"];
 $wlatitude=$row2["latitude"];
    $affected_region=$row2["affected_region"];
   
            $dist=distance($latitude,$longitude,$wlatitude,$wlongitude,"K");
   if($affected_region>= $dist)
   {
    $cls="alert alert-danger";
 }
 else
 {
  $cls="alert alert-success";
 }
}?>

    <tr class="<?php echo $cls ?>"><td><?php echo $count; ?></td><td><?php echo $row["bank"] ?></td>

<td>
 <div><b>Place:</b> <?php echo $row["place_name"] ?></div>
  <div><b>District:</b> <?php echo $row["district_name"] ?></div>
   <div><b>State:</b> <?php echo $row["state_name"] ?></div>
          </td>
              <td><?php echo $row["proper_place_name"] ?></td>
       



    </tr>
    

    <?php
    $count++;
}
}
else
{
  
  ?>
  <div class="alert alert-info" style="padding: 20px; margin:50px;">No List Available</div>
  <?php
}
?></tbody>
</table>  