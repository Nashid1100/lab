<?php session_start(); ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Rescue Guard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!-- Bootstrap Core CSS -->
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="../css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="../css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='../css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->
 
 <!-- js-->
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts--> 

<!-- chart -->
<script src="../js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="../js/metisMenu.min.js"></script>
<script src="../js/custom.js"></script>
<link href="../css/custom.css" rel="stylesheet">
<script type="text/javascript" src="../Ajax/ajax.js"></script>
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}
</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="../js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="../css/owl.carousel.css" rel="stylesheet">
					<script src="../js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>
					<!-- //requried-jsfiles-for owl -->
</head> 
<body class="cbp-spmenu-push">
	<?php
if(isset($_SESSION["slogid"]))
{
	?>
	<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <h1><a class="navbar-brand" href="login.php"><span><img src="../images/r.png" style="width:80%"></a></h1>
      
          </div>
          <br>
            <br>
            <br>
            <br>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
           <ul class="sidebar-menu">
              <li class="header"> </li>
              <li class="treeview ">
                <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Home</span>
                </a>
              </li>
              <li class="treeview">
                <a href="Profile_edit.php">
                <i class="fa fa-user"></i> <span>Profile Edit</span>
                </a>
              </li>

       <li class="treeview">
                <a href="disaster_warning.php">
                <i class="fa fa-sign-in"></i> <span>Disaster Warning</span>
                </a>
              </li>
             
              <li class="treeview active" >
                <a href="camp.php">
                <i class="fa fa-user"></i> <span>Camp Details</span>
                </a>
              </li>
               <li class="treeview ">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Information</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                 <ul class="treeview-menu">
                 
                    <li><a href="bank_branches.php"><i class="fa fa-angle-right"></i> Bank Branches</a></li>
                  <li><a href="atm.php"><i class="fa fa-angle-right"></i> ATM</a></li>
                  <li><a href="hospital.php"><i class="fa fa-angle-right"></i> Hospital</a></li>
                  <li><a href="police_station.php"><i class="fa fa-angle-right"></i> Police Station</a></li>
                </ul>
              </li>
                <li class="treeview">
                <a href="complaint.php">
                <i class="fa fa-user"></i> <span>Complaints</span>
                </a>
              </li>
             <li class="treeview">
                <a href="change_password.php">
                <i class="fa fa-user"></i> <span>Change Password</span>
                </a>
              </li>
               <li class="treeview">
                <a href="../logout.php">
                <i class="fa fa-sign-out"></i> <span>Log Out</span>
                </a>
              </li>
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>
		<!--left-fixed -navigation-->
		
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				
				<!--toggle button end-->
				<div class="profile_details_left"><!--notifications of menu start -->
		
					<div class="clearfix"> </div>
				</div>
				<!--notification menu end -->
				<div class="clearfix"> </div>
			</div>
			<div class="header-right">
				
				
		
				
				<div class="profile_details">		
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<div class="profile_img">	
									<span class="prfil-img"><img src="../images/2.jpg" alt=""> </span> 
									<div class="user-name">
										<p>User</p>
										<span><?php echo  $_SESSION["suname"]?></span>
									</div>
									<i class="fa fa-angle-down lnr"></i>
									<i class="fa fa-angle-up lnr"></i>
									<div class="clearfix"></div>	
								</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
							   <li>
                <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Home</span>
                </a>
              </li>
              
			
            
               <li>
                <a href="../logout.php">
                <i class="fa fa-sign-out"></i> <span>Log Out</span>
                </a>
              </li>
					</ul>
				</div>
				<div class="clearfix"> </div>				
			</div>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
			<div class="col_3">
        	
        	<div class="clearfix"> </div>
		</div>
		
	

				
	
	<!-- for amcharts js -->
			<script src="../js/amcharts.js"></script>
			<script src="../js/serial.js"></script>
			<script src="../js/export.min.js"></script>
			<link rel="stylesheet" href="../css/export.css" type="text/css" media="all" />
			<script src="../js/light.js"></script>
	<!-- for amcharts js -->

    <script  src="../js/index1.js"></script>
	
		<div class="charts">		
			<div class="mid-content-top charts-grids">
				<div class="middle-content">
						<div class="col-md-5 agileits_mail_grid_left">
          
             <h3 style="margin: 15px;">Search Relief Camp By Place</h3>
              <div class="form-group"> 
              <label>State</label>

                            <select name="state" id="state" class="form-control" onchange="display_district()">
                            <option value="">--Select--</option>
                            <?php
                                    
include('../dbconnection.php');
$db=new dbconnection;
$res= $db->execute_query("select * from tbl_state");
while($row=mysqli_fetch_array($res))
{
    ?>
    <option value="<?php echo $row["state_id"]?>"><?php echo $row["state_name"]?></option>

    <?php
}


                                    ?>
                            </select></div>
             <div class="form-group"> 
              <label>District</label>               
            
             
              <select name="district" id="district" class="form-control" onchange="display_place()">
                            <option value="">--Select--</option>
                            </select>
              </div>
               <div class="form-group"> 
              <label>Camp Place</label>               
            
           <select class="form-control" name="city" id="city"  onchange="display_camp()">
                            <option value="">--Select--</option>
                            </select>
              </div>
            </div><div class="col-md-5 agileits_mail_grid_right"></div>

<div class="clearfix"> </div>
						<h3 style="margin: 10px;">Camp List</h3>
						<div id="result">
              <?php
                                
         
$res= $db->execute_query("select * from tbl_camp inner join tbl_place on tbl_camp.place_id = tbl_place.place_id inner join tbl_district on tbl_district.district_id=tbl_place.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id");
$n=mysqli_num_rows($res);
if($n>0)
{
?>
 <table class="table table-striped table-bordered">
              <thead>
                <tr class="alert alert-info">
                  <th>No.</th>
                  <th>Camp Name</th>
                   <th>Place Details</th>
                    <th>Capacity</th>
                      <th>Registered Date</th>
                
                    
                     
                      


                </tr>
              </thead>
              <tbody>
<?php
$count=1;
while($row=mysqli_fetch_array($res))
{
    ?>

    <tr><td><?php echo $count; ?></td><td><?php echo $row["camp_name"] ?></td>

<td>
 <div><b>Place:</b> <?php echo $row["place_name"] ?></div>
  <div><b>District:</b> <?php echo $row["district_name"] ?></div>
   <div><b>State:</b> <?php echo $row["state_name"] ?></div>
          </td>
              <td><?php echo $row["capacity"] ?></td>
         <td><?php echo $row["reg_date"] ?></td>



    </tr>
    

    <?php
    $count++;
}
}
else
{
  
  ?>
  <div class="alert alert-info" style="padding: 20px; margin:50px;">No List Available</div>
  <?php
}
?></tbody>
</table>   </div> 
					<!-- start content_slider -->
				
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>
		
		<div class="col_1">
			<div class="col-md-4 span_8">
				
					
			</div>
			<div class="col-md-4 span_8">
				
			</div>
			<div class="col-md-4 span_8">
				
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
			
		</div>
				
			</div>
		</div>
	<!--footer-->
	<div class="footer">
	   <p> All Rights Reserved | Design by <a href="#" target="_blank">Rescue Guard</a></p>		
	</div>
    <!--//footer-->
	</div>
		
	<!-- new added graphs chart js-->
	
    
	<!-- //for index page weekly sales java script -->
	
	
	<!-- Bootstrap Core JavaScript -->
   <script src="../js/bootstrap.js"> </script>
	<!-- //Bootstrap Core JavaScript -->
	<?php 
}
else
{
	header("Location:../index.php");
}
	?>

</body>
</html>