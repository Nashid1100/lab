<?php
session_start();
$subject=$_POST["subject"];
$complaint=$_POST["complaint"];
$user_login_id=$_SESSION["slogid"];


//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
 
   $sql="insert into tbl_complaints(subject, complaint, user_login_id) values('$subject','$complaint','$user_login_id')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("complaint is added Successfully");
              window.location="complaint.php";

              </script>
            <?php 
        }
       ?>




